console.log("Email Writer Extension - Content Script Loaded");

// Inject CSS for water-fill animation
const style = document.createElement('style');
style.textContent = `
  .ai-reply-button {
    background-color: #1a73e8;
    color: #ffffff;
    padding: 0 24px;
    border: none;
    border-radius: 24px;
    height: 36px;
    line-height: 36px;
    font-size: 14px;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    margin-right: 8px;
    transition: all 0.3s ease;
  }

  .ai-reply-button.water-fill::before {
    content: '';
    position: absolute;
    bottom: -100%;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.3);
    animation: fillWater 2s ease forwards;
    z-index: 0;
  }

  .ai-reply-button span {
    position: relative;
    z-index: 1;
  }

  @keyframes fillWater {
    from {
      bottom: -100%;
    }
    to {
      bottom: 0;
    }
  }
`;
document.head.appendChild(style);

// Create the AI Reply button
function createAIButton() {
  const button = document.createElement('div');
  button.className = 'T-I J-J5-Ji aoO v7 T-I-atl L3 ai-reply-button';
  button.innerHTML = '<span>AI Reply</span>';
  button.setAttribute('role', 'button');
  button.setAttribute('data-tooltip', 'Generate AI Reply');
  return button;
}

// Extract email content from the compose window
function getEmailContent() {
  const selectors = ['.h7', '.a3s.aiL', '.gmail_quote', '[role="presentation"]'];
  for (const selector of selectors) {
    const content = document.querySelector(selector);
    if (content) {
      return content.innerText.trim();
    }
  }
  return '';
}

// Find Gmail's compose toolbar
function findComposeToolbar() {
  const selectors = ['.btC', '.aDh', '[role="toolbar"]', '.gU.Up'];
  for (const selector of selectors) {
    const toolbar = document.querySelector(selector);
    if (toolbar) {
      return toolbar;
    }
  }
  return null;
}

// Inject button into toolbar
function injectButton() {
  const existingButton = document.querySelector('.ai-reply-button');
  if (existingButton) existingButton.remove();

  const toolbar = findComposeToolbar();
  if (!toolbar) {
    console.log("Toolbar not found");
    return;
  }

  console.log("Toolbar found, creating AI button");
  const button = createAIButton();

  button.addEventListener('click', async () => {
    try {
      button.classList.add('water-fill');
      button.innerHTML = '<span>Generating...</span>';
      button.style.pointerEvents = 'none';
      const emailContent = getEmailContent();

      const response = await fetch('https://emailsender-v1-t6w4.onrender.com/api/email/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          emailContent: emailContent,
          tone: "professional"
        })
      });

      if (!response.ok) {
        throw new Error('API Request Failed');
      }

      const generatedReply = await response.text();
      const composeBox = document.querySelector('[role="textbox"][g_editable="true"]');

      if (composeBox) {
        composeBox.focus();
        document.execCommand('insertText', false, generatedReply);
      } else {
        console.error('Compose box was not found');
      }
    } catch (error) {
      console.error(error);
      alert('Failed to generate reply');
    } finally {
      button.innerHTML = '<span>AI Reply</span>';
      button.classList.remove('water-fill');
      button.style.pointerEvents = 'auto';
    }
  });

  toolbar.insertBefore(button, toolbar.firstChild);
}

// Observe DOM mutations to detect compose windows
const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    const addedNodes = Array.from(mutation.addedNodes);
    const hasComposeElements = addedNodes.some(node =>
      node.nodeType === Node.ELEMENT_NODE &&
      (node.matches('.aDh, .btC, [role="dialog"]') || node.querySelector('.aDh, .btC, [role="dialog"]'))
    );

    if (hasComposeElements) {
      console.log("Compose Window Detected");
      setTimeout(injectButton, 500);
    }
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});
